package com.springsource.roo.pizzashop.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Topping.class)
public class ToppingIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
