package freedays.timesheet;
public interface TimesheetGenerator {
	public void generateDoc(String wbname, int year, int month);
}
