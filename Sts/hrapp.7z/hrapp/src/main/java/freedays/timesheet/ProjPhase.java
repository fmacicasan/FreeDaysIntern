package freedays.timesheet;

import org.springframework.roo.addon.javabean.RooJavaBean;

@RooJavaBean
//@RooToString
//@RooEntity
public class ProjPhase {
}