package freedays.timesheet;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Schedule.class)
public class ScheduleDataOnDemand {
}
