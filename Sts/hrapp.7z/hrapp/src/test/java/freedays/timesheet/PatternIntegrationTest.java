package freedays.timesheet;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Pattern.class)
public class PatternIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
