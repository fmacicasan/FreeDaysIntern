package freedays.timesheet;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Phase.class)
public class PhaseIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
