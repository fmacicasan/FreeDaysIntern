package freedays.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Request.class)
public class RequestDataOnDemand {
}
