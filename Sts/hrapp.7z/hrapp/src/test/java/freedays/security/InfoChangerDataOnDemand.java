package freedays.security;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = InfoChanger.class)
public class InfoChangerDataOnDemand {
}
