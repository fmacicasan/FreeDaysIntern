package freedays.app;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = FDUser.class)
public class FDUserIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }

	@Test
    public void testRemove() {
//        freedays.app.FDUser obj = dod.getRandomFDUser();
//        org.junit.Assert.assertNotNull("Data on demand for 'FDUser' failed to initialize correctly", obj);
//        java.lang.Long id = obj.getId();
//        org.junit.Assert.assertNotNull("Data on demand for 'FDUser' failed to provide an identifier", id);
//        obj = freedays.app.FDUser.findFDUser(id);
//        obj.remove();
//        obj.flush();
//        org.junit.Assert.assertNull("Failed to remove 'FDUser' with identifier '" + id + "'", freedays.app.FDUser.findFDUser(id));
    }
}
