package freedays.app;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = FreeDayM.class)
public class FreeDayMIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
