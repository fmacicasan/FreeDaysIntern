package freedays.app;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = FDAdmin.class)
public class FDAdminIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
