package freedays.app;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = HRManagement.class)
public class HRManagementIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
