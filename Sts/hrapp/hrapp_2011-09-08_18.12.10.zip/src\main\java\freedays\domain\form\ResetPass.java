package freedays.domain.form;

import org.springframework.roo.addon.javabean.RooJavaBean;


/**
 * Wrapper for a ResetPassword request.
 * @author fmacicasan
 *
 */
@RooJavaBean
public class ResetPass {

	private String email;
	
}
