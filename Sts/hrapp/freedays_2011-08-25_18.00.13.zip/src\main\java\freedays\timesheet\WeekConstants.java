package freedays.timesheet;
public class WeekConstants {
	public static final String[] columnStrings = { "Line", "ProjectCode",
			"Phase", "Labor Code", "MON", "TUE", "WED", "THUR", "FRI", "SAT",
			"SUN", "TOTAL" };
	public static final int rowsBetweenTables = 5;
}
