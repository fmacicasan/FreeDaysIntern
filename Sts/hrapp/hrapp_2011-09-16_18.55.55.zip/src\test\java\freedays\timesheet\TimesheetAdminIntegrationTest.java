package freedays.timesheet;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = TimesheetAdmin.class)
public class TimesheetAdminIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
