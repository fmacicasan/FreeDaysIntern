package freedays.app;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = FreeDayRL.class)
public class FreeDayRLDataOnDemand {
}
