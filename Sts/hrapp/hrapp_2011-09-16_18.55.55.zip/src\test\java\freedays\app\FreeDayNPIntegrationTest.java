package freedays.app;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = FreeDayNP.class)
public class FreeDayNPIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
