package freedays.timesheet;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Project.class)
public class ProjectIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
