package logging;

public enum LogLevel {
		  DEBUG,
		  ERROR,
		  FATAL,
		  INFO,
		  TRACE,
		  WARN
}
